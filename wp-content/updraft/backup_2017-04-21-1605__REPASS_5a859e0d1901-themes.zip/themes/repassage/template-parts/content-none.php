<section class="no-results not-found">
    <span class="global-title">Ничего не найдено</span>
    <div class="page-content">
        <p>К сожалению в данном разделе нет никакой информации.</p>
    </div>
</section>
