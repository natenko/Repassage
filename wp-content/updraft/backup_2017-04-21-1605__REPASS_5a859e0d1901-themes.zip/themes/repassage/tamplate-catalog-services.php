<?php
/*
Template Name: Каталог услуг
*/
get_header(); ?>
<div class="catalog-services">
    <div class="services-home">
        <span class="global-title"><?php echo the_title() ?></span>
        <div class="services-home__carousel-output">
            0<span class="services-home__carouse-output__current"></span> / 0<span
                class="services-home__carouse-output__count"></span>
        </div>
        <div class="global-box-text">
            <span class="title"><?php echo get_field('подзаголовок') ?></span>
            <?php echo get_field('контент_сервисы') ?>
        </div>
        <ul>

            <?php
            $mypages = get_pages(array(
                'parent' => $post->ID,
                'sort_column' => 'menu_order',
                'sort_order' => 'ASC'));
            foreach ($mypages as $post) {
                setup_postdata($post);

                get_template_part('template-parts/content', 'service');

            }
            wp_reset_postdata(); ?>

        </ul>
    </div>
    <?php include('contact.php'); ?>
</div>
<?php include('map.php');
include('seo-text.php'); ?>
<?php get_footer(); ?>
<script>
    const outputServiceCounts = $('.services-home__carouse-output__count');
    const outputServiceCurrents = $('.services-home__carouse-output__current');
    $(".services-home ul").on('init', function () {
        outputServiceCounts.html($('.services-home ul .slick-slide').length);
        outputServiceCurrents.html(1);
    });
    $(".services-home ul").on('afterChange', function (event, slick, current) {
        outputServiceCounts.html($('.services-home ul .slick-slide').length);
        outputServiceCurrents.html(current + 1);
    });
</script>

