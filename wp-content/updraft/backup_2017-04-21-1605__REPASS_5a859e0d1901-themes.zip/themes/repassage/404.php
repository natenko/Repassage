<?php get_header(); ?>

<div class="box-404">
	<div class="item-404">
		<span>Cтраница не найдена...</span>
		<span class="text">Мы приносим свои извинения за прчиненные неудобства. Просим Вас вернуться назад или перейти на главную страницу.</span>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную</a>
	</div>
</div>


